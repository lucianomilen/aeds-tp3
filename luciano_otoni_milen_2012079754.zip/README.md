# aeds-tp3
## Luciano Otoni Milen [2012079754]
Ao rodar o comando `make`, os executáveis `tp3fb` e `tp3h` são gerados. `./<executavel>` roda o programa selecionado.
